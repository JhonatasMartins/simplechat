package br.upis.chat;

/**
 *
 * @author jhonatas
 */
public enum MessageType {
    
    connect,
    disconnect,
    sending,
    command
    
}
