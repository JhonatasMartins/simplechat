package br.upis.chat;

/**
 *
 * @author jhonatas
 */
public enum Command {
    
    quit,
    list
    
}
