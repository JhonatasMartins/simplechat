package br.upis.chat.server;

import br.upis.chat.Message;

/**
 *
 * @author jhonatas
 */
public interface IServerWriter {
    
    public void writerAllsUsers(Message message);
    
}
