package br.upis.chat.client;

import br.upis.chat.Command;
import br.upis.chat.Message;
import br.upis.chat.MessageType;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/**
 *
 * @author jhonatas
 */
public class ClientWriter implements Runnable{

    private static final String COMMAND = "/";
    
    private ObjectOutputStream oos;
    private String username;
    private ICloseListener listener;
    
    public ClientWriter(String username, ObjectOutputStream oos, 
                        ICloseListener listener){
        this.username = username;
        this.oos = oos;
        this.listener = listener;
    }
    
    @Override
    public void run() {
       //Novo scanner usando o teclado como entrada
       Scanner scanner = new Scanner(System.in);
            
       try{
            while(true){
                //operação bloqueante, travar até ser digitado algo e apertado enter
                String line = scanner.nextLine();    
                
                //limpa o que está no buffer
                oos.flush();
                
                MessageType type = getType(line);
                
                //manda a nova mensagem para o socket
                oos.writeObject(new Message(username, line, type));
                
                if(type == MessageType.command && 
                   getCommand(line) == Command.quit){
                    
                    close();   
                }
            }
       }catch(IOException e){
           e.printStackTrace();
       }
    }
    
    private void close(){
        try{
            oos.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        
        listener.close();
    }
    
    /**
     * Verifica se a entrada do teclado é um comando ou uma
     * String, por default retorna MessageType.sending, 
     * se for a String for um comando deve retornar MessageType.command
     * 
     * @param line
     * @return 
     */
    private MessageType getType(String line){
         MessageType type =  MessageType.sending;
        
        if(line != null && !line.isEmpty() && line.startsWith(COMMAND))
            type = MessageType.command;
        
        return type;
    }
    
    /**
     * Tenta obter através da String um comando,
     * se o mesmo existir no enum Command
     * 
     * @param line
     * @return 
     */
    private Command getCommand(String line){
        Command command = null;
        
        if(line != null && !line.isEmpty()){
            String comm = line.trim().replaceFirst(COMMAND, "");
            
            command = Command.valueOf(comm);
        }
        
        return command;
    }
}
