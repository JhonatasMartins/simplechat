package br.upis.chat.client;

/**
 *
 * @author jhonatas
 */
public interface ICloseListener {
    
    public void close();
    
}
